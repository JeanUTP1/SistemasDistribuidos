package modelo;

import java.sql.*;

public class Conexion {
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/tiendapcdos", 
                "root", 
                "123"
            );
            System.out.println("Base de datos conectada");
            return conn;
        } catch (Exception e) {
            System.out.println("Error al conectar" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}