package controlador;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
import modelo.Conexion;

@WebServlet("/GuardarCliente")
public class GuardarClienteServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nombreCliente = request.getParameter("nombreCliente");
        String emailCliente = request.getParameter("emailCliente");
        String telefonoCliente = request.getParameter("telefonoCliente");
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = Conexion.getConnection();
            String sql = "INSERT INTO clientes (nombreCliente, emailCliente, telefonoCliente) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombreCliente);
            pstmt.setString(2, emailCliente);
            pstmt.setInt(3, Integer.parseInt(telefonoCliente));
            pstmt.executeUpdate();
            
            response.sendRedirect("Clientes");
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}